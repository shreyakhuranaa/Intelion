import React from "react";

const Hero = () => {
  return (
    <section className="bg-indigo-600 text-white text-center py-20">
      <h2 className="text-4xl font-bold">Empowering Businesses with Cutting-Edge Solutions</h2>
      <p className="mt-4 text-lg">Innovate, Transform, and Excel with Intelion</p>
      <button className="mt-6 px-6 py-2 bg-white text-indigo-600 font-bold rounded-md hover:bg-gray-200">
        Get Started
      </button>
    </section>
  );
};

export default Hero;